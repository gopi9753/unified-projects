![Banner](https://telegra.ph/file/7004f3624b096308ad3f0.jpg)

# Image Slider

Image slider is a popular way to showcase your products, services or just about anything. The design of the slider can make or break the presentation. You may have seen some sliders that do not work well on mobile and are not responsive. This is where CSS3 comes in handy.

This image slider have a responsive slider that looks great on all devices with pure CSS3 and JavaScript.

We will be using jQuery library for this tutorial but it is not necessary as we can use any other JavaScript library like MooTools, YUI, Prototype or even vanilla JavaScript if you want to.

## ╔═━「 Creator Info 」

+ [Rachit-Pal](https://github.com/Rachit-Pal) : CREATOR
+ [Straw Hat](https://github.com/StrawhatNetwork) : NETWORK
